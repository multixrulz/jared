#  This program is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program.  If not, see <http://www.gnu.org/licenses/>.
#

from PyQt5 import QtGui, QtCore
import datetime

class LQItem(QtGui.QStandardItem):
    """
    A subclassed QStandardItem that allows for sane handling of non-string
    items.

    Trees are allowed, as long as you send in both rows and columns as arguments,
    and not rows only.
    """
    def __init__(self, data, *args, **kwargs):
        """
        Create the model.

        data: the data to be displayed by the item.
        """
        # QStandardItem has two function signatures with a single argument:
        # one is a string, the other is an integer for creating trees.
        # The second possibility is ignored.
        if len(args) == 0:
            super().__init__(None, *args, **kwargs)
            self.set_item_data(data)
        else:
            super().__init__(data, *args, **kwargs)
        self.setEditable(False)

    def original_data(self):
        """
        Get the unmodified data sent in through the constructor or the
        set_item_data() method.
        """
        return self._data

    def set_item_data(self, data):
        """
        Set the data to be displayed by the item.

        data: the data to be displayed.
            QPixmap or QIcon: displayed as an image.
            datetime.date: displayed as a string
            decimal.Decimal: Qt doesn't handle this by default.
                displayed with at least 2 decimal places, more if there are
                non-zero digits.
            boolean: displayed as a checkbox.
        """
        self._data = data
        if isinstance(data, datetime.date):
            # TODO: allow user-definable date string
            display = data.strftime('%d %B %Y (%a)')
        elif data == None:
            display = ''
        else:
            display = str(data)
        # Set the DisplayRole data
        self.setData(display, QtCore.Qt.DisplayRole)

    def __lt__(self, other):
        # Define our own less-than method: this is what Qt uses for sorting
        try:
            result = self._data < other._data
        except TypeError:
            # If the types are unorderable, just return True
            result = True
        return result


class LQCalendarFilterProxyModel(QtCore.QSortFilterProxyModel):
    def __init__(self, column, *args, **kwargs):
        """
        Create the proxy.
        """
        self._column = column
        super().__init__(*args, **kwargs)

    def filterAcceptsRow(self, sourcerow, parent):
        return self.sourceModel().item(sourcerow, self._column).original_data() is not None

    def itemFromIndex(self, proxy_index):
        source_index = self.mapToSource(proxy_index)
        return self.sourceModel().itemFromIndex(source_index)

class LQPriorityFilterProxyModel(QtCore.QSortFilterProxyModel):
    def __init__(self, column, *args, **kwargs):
        """
        Create the proxy.
        """
        self._column = column
        self._tags = set()
        super().__init__(*args, **kwargs)

    def filterAcceptsRow(self, sourcerow, parent):
        if len(self._tags) == 0:
            return True
        else:
            row_tags = self.sourceModel().item(sourcerow, self._column).original_data()
            return self._tags.issubset(row_tags)

    def set_tags(self, tags):
        self._tags = tags
        self.invalidateFilter()

    def itemFromIndex(self, proxy_index):
        source_index = self.mapToSource(proxy_index)
        return self.sourceModel().itemFromIndex(source_index)

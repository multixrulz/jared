#  This program is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program.  If not, see <http://www.gnu.org/licenses/>.
#

from PyQt5 import QtWidgets, QtGui, uic
import sys
import os
from xdg import BaseDirectory
import configparser
import markdown
import datetime

from . defs import *
from .backend import quest
from .qt_extensions import *
from . import build_config

#import json


# LifeQuest is based loosely on GTD -- which means that I've heard some things
# about GTD and seen some programs which have influenced LifeQuest
# Quest -- The Todo list
# Tags -- Tags!  Tags beginning with @ should be interpreted as "Locations" -- ie
#         contexts, orplaces where an action is done.  Tags without an @ should be
#         interpreted as "Adventures", ie projects.
# Feats -- These are todo items on the list.

class LQMainWindow(QtWidgets.QMainWindow):
    def __init__(self, app, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._app = app
        config_dir = BaseDirectory.save_config_path("LifeQuest")
        self._config_file_name = os.path.join(config_dir, "LifeQuest.conf")
        data_dir = BaseDirectory.save_data_path("LifeQuest")
        self._quest_file_name = os.path.join(data_dir, "Quest.data")
        self._init_config()
        self._init_data()
        self._init_gui()
        self.show()

    def _init_config(self):
        # Read in the configuration, with defaults
        app_defaults = {'Interface': {'splitter_webView': 550,
            'splitter_feat': 200,
            'window_width': 900,
            'window_height': 500}
            }
        # Create a configparser object, initialise it with defaults,
        # and read in the config file
        self._config = configparser.SafeConfigParser()
        self._config.read_dict(app_defaults)
        self._config.read(self._config_file_name)

    def _init_data(self):
        self._adventure_model = QtGui.QStandardItemModel()
        self._location_model = QtGui.QStandardItemModel()
        self._feat_model = QtGui.QStandardItemModel()
        self._read_quest()

    def _init_gui(self):
        uic.loadUi(os.path.join(build_config.UI_DIR, "LQMainWindow.ui"), self)
        # Set window and splitter sizes
        width = self._config.getint('Interface', 'window_width')
        height = self._config.getint('Interface', 'window_height')
        self.resize(QtCore.QSize(width, height))
        self.splitter_preview.setSizes((5000,3000))
        self.splitter_feat.setSizes((2000,4500))
        # Set contents margin on vertical layout - can't be done in designer
        self.vlayout_feat.setContentsMargins(0, 0, 0, 0)
        # Set up treeviews (sorting happens when data is entered into the model)
        self.treeView_adventure.setModel(self._adventure_model)
        self.treeView_location.setModel(self._location_model)
        self._priority_proxy = LQPriorityFilterProxyModel(3)
        self._priority_proxy.setSourceModel(self._feat_model)
        self.treeView_priority.setModel(self._priority_proxy)
        self._calendar_proxy = LQCalendarFilterProxyModel(2) # Filter on column 2
        self._calendar_proxy.setSourceModel(self._feat_model)
        self._calendar_proxy.setFilterWildcard('?*') # At least 1 char
        self.treeView_calendar.setModel(self._calendar_proxy)
        # Treeview selections
        sm = self.treeView_priority.selectionModel()
        sm.selectionChanged.connect(self._feat_selection_changed)
        sm = self.treeView_calendar.selectionModel()
        sm.selectionChanged.connect(self._feat_selection_changed)
        # Populate treeview models
        self._reload_feat_model()
        self._reload_tags()

    def _read_quest(self):
        quest.read_quest(self._quest_file_name)

    def _save_quest(self):
        quest.save_quest(self._quest_file_name)

    def _refresh_quest(self):
        self._reload_feat_model()
        self._reload_tags()

    def _save_config(self):
        size = self.size()
        self._config.set("Interface", "window_width", str(size.width()))
        self._config.set("Interface", "window_height", str(size.height()))
        config_dir = BaseDirectory.save_config_path("LifeQuest")
        configfile = open(self._config_file_name, 'w')
        self._config.write(configfile)

    def _get_selected_title(self):
        # Get title of currently selected feat
        page = self.tabWidget.currentIndex()
        if page == 0:
            sm = self.treeView_priority.selectionModel()
            model = self._priority_proxy
        elif page == 1:
            sm = self.treeView_calendar.selectionModel()
            model = self._calendar_proxy
        else:
            return None
        indexes = sm.selectedRows(0)
        if len(indexes) == 0:
            return None
        else:
            return model.itemFromIndex(indexes[0]).original_data()

    def _feat_selection_changed(self):
        title = self._get_selected_title()
        self._set_preview(title)
        self._set_next_date_button_enabled(title)
        self.actionDelete.setEnabled(title is not None)
        self.actionEdit.setEnabled(title is not None)

    def _set_next_date_button_enabled(self, title):
        feat_details = quest.get_feat_details(title)
        if feat_details != None:
            self.actionNext.setEnabled(feat_details["recurrence"][0] != RECURS_NONE)
        else:
            self.actionNext.setEnabled(False)

    def _about(self):
        version = "0.5"
        title = "About LifeQuest"
        text = """<p>LifeQuest &mdash; Manage the adventures of your life!</p>
            <p>Version %s</p>
            <p><a href="http://jared.henley.id.au/software/lifequest/">LifeQuest website</a></p>
            <p>This program is licenced under the GNU General Public License, version 3 or later.</p>
            <p>Copyright &copy; 2015 Jared Henley</p>""" % (version)
        msgbox = QtWidgets.QMessageBox.about(self, title, text)

    def _add(self):
        self._feat_edit_create()

    def _delete(self):
        title = self._get_selected_title()
        if title != None:
            quest.remove_feat(title)
        self._reload_feat_model()
        self._reload_tags()

    def _edit(self):
        title = self._get_selected_title()
        if title != None:
            self._feat_edit_create(title)

    def _next_occurrence(self):
        title = self._get_selected_title()
        if title != None:
            quest.feat_set_next_recurrence(title)
            self._reload_feat_model_item(title, title)

    def _reload(self):
        self._reload_feat_model()

    def _save(self):
        self._save_quest()

    def _add_adventure(self):
        old_tags = set(self.lineEdit_filter.text().split(' '))
        sm = self.treeView_adventure.selectionModel()
        indexes = sm.selectedIndexes()
        new_tags = set(self._adventure_model.itemFromIndex(i).original_data() for i in indexes)
        self.lineEdit_filter.setText(' '.join(old_tags.union(new_tags)).strip())
        self._tag_refilter()

    def _add_location(self):
        old_tags = set(self.lineEdit_filter.text().split(' '))
        sm = self.treeView_location.selectionModel()
        indexes = sm.selectedIndexes()
        new_tags = set(self._location_model.itemFromIndex(i).original_data() for i in indexes)
        self.lineEdit_filter.setText(' '.join(old_tags.union(new_tags)).strip())
        self._tag_refilter()

    def _feat_edit_create(self, title=None):
        if title is None:
            feat_details = None
        else:
            feat_details = quest.get_feat_details(title)
        # Show the feat details window
        feat_window = FeatDetails(title)
        result = feat_window.exec()
        # Blocks until feat details window is closed.
        if result == QtWidgets.QDialog.Accepted:
            new_title = feat_window.feat_title()
            feat_details = quest.get_feat_details(new_title)
            if title is None:
                self._load_feats_into_model([feat_details,])
            else:
                self._update_feat_model(new_title, title) # update only this item
            self._reload_tags()

    def _update_feat_model(self, title, orig_title):
        title_items = self._feat_model.findItems(orig_title, column=0)
        # Should only match one, but not to worry
        for i in title_items:
            row = i.row()
            feat_details = quest.get_feat_details(title)
            self._feat_model.item(row, 0).set_item_data(title)
            self._feat_model.item(row, 1).set_item_data(feat_details["effective priority"])
            self._feat_model.item(row, 2).set_item_data(feat_details["date"])
            self._feat_model.item(row, 3).set_item_data(feat_details["tags"])
        self._feat_selection_changed()

    def _reload_feat_model(self):
        self._feat_model.clear()
        self._load_feats_into_model(quest.get_feats())
        self._feat_model.setHorizontalHeaderLabels(('Feats to Perform', 'Priority', 'Date', 'Tags'))
        # Priority treeview
        self.treeView_priority.hideColumn(1)
        self.treeView_priority.hideColumn(2)
        self.treeView_priority.hideColumn(3)
        self.treeView_priority.setSortingEnabled(True)
        self.treeView_priority.header().setSortIndicatorShown(False)
        self.treeView_priority.sortByColumn(1, QtCore.Qt.AscendingOrder)
        # Calendar treeview
        self.treeView_calendar.hideColumn(1)
        self.treeView_calendar.hideColumn(3)
        self.treeView_calendar.setSortingEnabled(True)
        self.treeView_calendar.header().setSortIndicatorShown(False)
        self.treeView_calendar.sortByColumn(2, QtCore.Qt.AscendingOrder)
        self.treeView_calendar.resizeColumnToContents(0)
        # Actions and preview
        self.actionDelete.setEnabled(False)
        self.actionEdit.setEnabled(False)
        self.actionNext.setEnabled(False)
        self._blank_preview()

    def _load_feats_into_model(self, feats):
        for f in feats:
            row = [LQItem(f["title"]),
                LQItem(f["effective priority"]),
                LQItem(f["date"]),
                LQItem(set(f["tags"]))]
            self._feat_model.appendRow(row)

    def _reload_tags(self):
        self._location_model.clear()
        self._adventure_model.clear()
        for t in quest.tags:
            if t.startswith('@'):
                self._location_model.appendRow(LQItem(t))
            else:
                self._adventure_model.appendRow(LQItem(t))
        self._location_model.setHorizontalHeaderLabels(('Locations',))
        self.treeView_location.setSortingEnabled(True)
        self.treeView_location.header().setSortIndicatorShown(False)
        self.treeView_location.sortByColumn(0, QtCore.Qt.AscendingOrder)
        self._adventure_model.setHorizontalHeaderLabels(('Adventures',))
        self.treeView_adventure.setSortingEnabled(True)
        self.treeView_adventure.header().setSortIndicatorShown(False)
        self.treeView_adventure.sortByColumn(0, QtCore.Qt.AscendingOrder)

    def _set_preview(self, feat_title):
        feat_details = quest.get_feat_details(feat_title)
        if feat_details == None:
            self._blank_preview()
        else:
            if feat_details["tags"] == set():
                tags = 'No tags'
            else:
                tags = ", ".join(feat_details["tags"])
            if feat_details["date"] == None:
                date_label = "Date:"
            else:
                date_label = feat_details["datetype"]
            if feat_details["recurrence"] == None:
                recurs = 'Never'
            else:
                (recurrence_type, recurrence_skip) = feat_details["recurrence"]
                if recurrence_type == RECURS_NONE:
                    recurs = recurrence_type
                else:
                    if recurrence_skip > 1:
                        recurs = 'every ' + str(recurrence_skip) + ' ' + recurrence_type
                    else:
                        recurs = 'every ' + recurrence_type[:-1]
            if feat_details["notes"].strip() == '':
                notes = 'No notes'
            else:
                notes = feat_details["notes"].replace('\n', '<br>')
            html = HTML_TEMPLATE % (
                QtGui.QPalette().window(),
                QtGui.QPalette().text(),
                feat_details["title"],
                tags,
                PRIORITIES[feat_details["priority"]-1],
                feat_details["effective priority"],
                date_label,
                lq_date_string(feat_details["date"], DATE_FORMAT_DISPLAY),
                recurs,
                markdown.markdown(notes),
                lq_date_string(feat_details["created"], DATE_FORMAT_DISPLAY))
            self.webView_feat.setHtml(html)

    def _blank_preview(self):
        html = HTML_BLANK % (QtGui.QPalette().window())
        self.webView_feat.setHtml(html)

    def _tag_refilter(self):
        tags = set(self.lineEdit_filter.text().strip().split(' ')) - set([''])
        self._priority_proxy.set_tags(tags)
        self._feat_selection_changed()

    def _clear_filter(self):
        self.lineEdit_filter.setText("")
        self._tag_refilter()

    def closeEvent(self, event):
        self._save_quest()
        self._save_config()


class FeatDetails(QtWidgets.QDialog):
    def __init__(self, feat_title, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._title = feat_title
        self._init_gui()
        self._init_data()
        self.show()

    def _init_gui(self):
        uic.loadUi(os.path.join(build_config.UI_DIR, "LQFeatWindow.ui"), self)
        self.comboBox_priority.addItems(PRIORITIES)
        self.comboBox_date.addItems(DATE_TYPES)
        self.comboBox_recurs.addItems(RECUR_TYPES)

    def _init_data(self):
        if self._title is not None:
            feat_details = quest.get_feat_details(self._title)
            self.lineEdit_title.setText(feat_details["title"])
            self.lineEdit_tags.setText(" ".join(feat_details["tags"]))
            self.comboBox_priority.setCurrentIndex(feat_details["priority"] - 1)
            self.comboBox_date.setCurrentText(feat_details["datetype"])
            if feat_details["date"] is None:
                self.dateEdit_date.setDate(datetime.date.today())
            else:
                self.dateEdit_date.setDate(feat_details["date"])
            self.comboBox_recurs.setCurrentText(feat_details["recurrence"][0])
            self.spinBox_recurs.setValue(feat_details["recurrence"][1])
            self.plainTextEdit_notes.setPlainText(feat_details["notes"])
        else:
            self.comboBox_priority.setCurrentIndex(5)
            self.comboBox_date.setCurrentIndex(0)
            self.comboBox_recurs.setCurrentIndex(0)
            self._title_changed()

    def _datetype_changed(self):
        self.dateEdit_date.setVisible(self.comboBox_date.currentIndex() != 0)
        self.label_recurs.setVisible(self.comboBox_date.currentIndex() != 0)
        self.comboBox_recurs.setVisible(self.comboBox_date.currentIndex() != 0)
        self.spinBox_recurs.setVisible(self.comboBox_date.currentIndex() != 0)

    def _recurrencetype_changed(self):
        self.spinBox_recurs.setEnabled(self.comboBox_recurs.currentIndex() != 0)

    def _title_changed(self):
        self.pushButton_save.setEnabled(len(self.lineEdit_title.text()) > 0)

    def _save(self):
        # Get data out of widgets
        title = self.lineEdit_title.text()
        tags = set(self.lineEdit_tags.text().split(' '))
        priority = self.comboBox_priority.currentIndex() + 1
        if self.comboBox_date.currentIndex() == 0:
            datetype = None
            date = None
        else:
            datetype = self.comboBox_date.currentText()
            date = self.dateEdit_date.date().toPyDate()
            date = datetime.datetime(date.year, date.month, date.day)
        recurrence_type = self.comboBox_recurs.currentText()
        recurrence_interval = self.spinBox_recurs.value()
        recurrence = [recurrence_type, recurrence_interval]
        notes = self.plainTextEdit_notes.toPlainText()
        if self._title is not None:
            quest.retitle_feat(self._title, title)
        quest.add_edit_feat(title, tags, priority, datetype, date, recurrence, notes)
        self._title = title
        self.accept()

    def feat_title(self):
        return self._title

    def _cancel(self, button):
        self.window.destroy()

    def _completion_match_function(self, completion, lowercase_entry_string, iter, data):
        # Get some data we need
        model = completion.get_model()
        test_word = model[iter][0]
        cursor_position = self.tags.get_property("cursor-position")
        # Get the unmodified text (default is lower case)
        entry_string = completion.get_entry().get_text()
        # Determine the space-delimited word that we're in
        (first_part, last_part) = self._completion_get_word(entry_string, cursor_position)
        if first_part == '' or last_part != '': #Only match at the end of a non-empty word
            return False
        # Matches if the word we're in starts the test word
        return test_word.startswith(first_part)

    def _on_completion_match(self, completion, model, iter):
        # Get some data we need
        entry_string = self.tags.get_text()
        model = completion.get_model()
        complete_word = model[iter][0]
        current_text = self.tags.get_text()
        cursor_position = self.tags.get_position()
        # Find out what to add to the string
        (first_part, last_part) = self._completion_get_word(entry_string, cursor_position)
        part_word = first_part + last_part
        insert_string = complete_word[len(part_word):]
        self.tags.insert_text(insert_string, cursor_position)
        # Put the cursor in the right position
        self.tags.set_position(cursor_position + len(insert_string))
        # stop the event propagation
        return True

    def _completion_get_word(self, entry_string, cursor_position):
        first_part = entry_string[:cursor_position].split(' ')[-1]
        last_part = entry_string[cursor_position:].split(' ')[0]
        return (first_part, last_part)


def exec():
    """
    Execute the Revelation program.

    Simply import this module and execute this exec() function.
    """
    # Create an application object
    app = QtWidgets.QApplication(sys.argv)

    # Set an icon for the application
    app_icon = QtGui.QIcon(os.path.join(build_config.GRAPHICS_DIR, 'lifequest.svg'))
    app.setWindowIcon(app_icon)

    # Create and show the main window -- the window shows itself
    main_window = LQMainWindow(app)

    # Execute the application -- get the event loop running
    return app.exec()

    app.exec()


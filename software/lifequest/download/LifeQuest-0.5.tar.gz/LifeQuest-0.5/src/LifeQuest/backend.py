#  This program is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program.  If not, see <http://www.gnu.org/licenses/>.
#

import datetime
import os
import json
import dateutil.relativedelta, dateutil.parser
#from xdg import BaseDirectory
#import configparser
#from gi.repository import Gtk, GdkPixbuf, Pango, WebKit
#import io
#import markdown

from .defs import *


class Quest:
    """A ToDo list"""
    def __init__(self):
        self._feats = []
        self._tags = set()

    def add_edit_feat(self, title="", tags=set(), priority=5, datetype=None,
        date=None, recurrence=(RECURS_NONE, 0), notes="", created=datetime.datetime.now()):
        """ Add a feat -- or change it if it already exists"""
        tags = tags - set([''])
        found = False
        for f in self._feats:
            if f.title == title:
                f.modify(tags, priority, datetype, date, recurrence, notes)
                found = True
                break
        if not found:
            new_feat = _Feat(title, tags, priority, datetype, date, recurrence, notes, created)
            self._feats.append(new_feat)
        self._compute_tags()

    def retitle_feat(self, orig_title, title):
        for f in self._feats:
            if f.title == orig_title:
                f.retitle(title)

    def remove_feat(self, title):
        for i in range(len(self._feats)):
            if self._feats[i].title == title:
                self._feats.pop(i)
                break
        self._compute_tags()

    def feat_set_next_recurrence(self, title):
        for f in self._feats:
            if f.title == title:
                f.set_next_recurrence()

    def get_feats(self):
        """ Return a list of feats"""
        return [f.get_dict() for f in self._feats]

    @property
    def tags(self):
        """ Return a list of all tags"""
        return self._tags

    def get_feat_details(self, title):
        """ Return the feat with the specified title"""
        for f in self._feats:
            if f.title == title:
                return f.get_dict()
        return None

    def save_quest(self, filename):
        all_feats = [feat.get_serialisable() for feat in self._feats]
        temp_filename = "%s.tmp" % (filename)
        backup_filename = "%s.bak" % (filename)
        with open(temp_filename, mode='w', encoding='utf-8') as f:
            json.dump(all_feats, f, indent=2)
        f.close()
        if os.path.isfile(filename):
            os.rename(filename, backup_filename)
        os.rename(temp_filename, filename)

    def read_quest(self, filename):
        self._quest = Quest()
        if os.path.isfile(filename):
            with open(filename, mode='r', encoding='utf-8') as f:
                feats = json.load(f)
            f.close()
            for f in feats:
                date = f["date"]
                if date != None:
                    date = dateutil.parser.parse(date)
                created = f["created"]
                if created != None:
                    created = dateutil.parser.parse(created)
                self.add_edit_feat(f["title"], set(f["tags"]), f["priority"],
                    f["datetype"], date, f["recurrence"], f["notes"], created)

    def _compute_tags(self):
        self._tags = set()
        for f in self._feats:
            self._tags = self.tags | f.tags


class _Feat:
    """A ToDo Item"""
    def __init__(self, title, tags, priority, datetype, date, recurrence, notes, created):
        # Clean up funny data
        if recurrence is None:
            recurrence = [RECURS_NONE, 0]
        if datetype is None:
            date = None
            recurrence = [RECURS_NONE, 0]
        # Populate
        self.title = title
        self.tags = tags
        self.priority = priority
        self.datetype = datetype
        if datetype == None:
            self.date = None
        else:
            self.date = date
        self.recurrence = recurrence
        self.notes = notes
        self.created = created

    def modify(self, tags, priority, datetype, date, recurrence, notes):
        # Clean up funny data
        if recurrence is None:
            recurrence = [RECURS_NONE, 0]
        if datetype is None:
            date = None
            recurrence = [RECURS_NONE, 0]
        # Populate
        self.tags = tags
        self.priority = priority
        self.datetype = datetype
        self.date = date
        self.recurrence = recurrence
        self.notes = notes

    def retitle(self, title):
        self.title = title

    def set_next_recurrence(self):
        (recurrence_type, recurrence_skip) = self.recurrence
        if recurrence_type == RECURS_NONE:
            return
        else:
            self.created = min(self.date, datetime.datetime.now())
            if recurrence_type == RECURS_DAILY:
                skip = dateutil.relativedelta.relativedelta(days=recurrence_skip)
            elif recurrence_type == RECURS_WEEKLY:
                skip = dateutil.relativedelta.relativedelta(weeks=recurrence_skip)
            elif recurrence_type == RECURS_MONTHLY:
                skip = dateutil.relativedelta.relativedelta(months=recurrence_skip)
            elif recurrence_type == RECURS_YEARLY:
                skip = dateutil.relativedelta.relativedelta(years=recurrence_skip)
            self.date += skip

    def has_tags(self, tags):
        return self.tags >= tags

    def get_dict(self):
        return {"title": self.title,
            "tags": self.tags,
            "priority": self.priority,
            "effective priority": self.effective_priority,
            "datetype": self.datetype,
            "date": self.date,
            "recurrence": self.recurrence,
            "notes": self.notes,
            "created": self.created}

    def get_serialisable(self):
        return {"title": self.title,
            "tags": list(self.tags),
            "priority": self.priority,
            "datetype": self.datetype,
            "date": lq_date_string(self.date, DATE_FORMAT_JSON, None),
            "recurrence": self.recurrence,
            "notes": self.notes,
            "created": lq_date_string(self.created, DATE_FORMAT_JSON, None)}

    @property
    def effective_priority(self):
        if self.datetype == DEADLINE and self.date != None:
            span = self.date - self.created
            if span <= datetime.timedelta(0):
                # Elevate past-deadline feats to top of list
                adjustment = self.priority + 1
            else:
                # Elevate coming feats so that the nearer they get, the
                # higher they get.  Set it up so that feats that have only
                # just started into their span have low priorities, and feats
                # that are just about due appear at the top.
                consumed = datetime.datetime.now() - self.created
                #remaining = self.date - datetime.datetime.now()
                #adjustment = self.priority * (abs(span) / remaining)
                curve = (consumed / abs(span)) * (consumed / abs(span)) * (consumed / abs(span))
                adjustment = (10 - self.priority) * (curve - 1)
        elif self.datetype == EVENT and self.date != None:
            if datetime.datetime.now() >= self.date:
                # Elevate today or past events to top of list
                adjustment = self.priority + 1
            else:
                adjustment = 0
        else:
            adjustment = 0
        return float(self.priority) - float(adjustment)


quest = Quest()

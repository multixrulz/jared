#  This program is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program.  If not, see <http://www.gnu.org/licenses/>.
#

HTML_TEMPLATE = """
<html>
    <style type="text/css">
    * {font-family: sans; font-size: 11pt; background: %s; color: %s}
    h1 {font-size: 130%%; font-weight: bold;}
    dl {display: inline;}
    dt {font-weight: bold;}
    dd {margin-top: -1em;}
    </style>
    <body>
        <h1>%s</h1>
        <dl>
            <dt>Tags:</dt>
            <dd><p>%s</p></dd>
        </dl>
        <dl>
            <dt>Importance:</dt>
            <dd><p>%s</p></dd>
        </dl>
        <dl>
            <dt>Current Priority:</dt>
            <dd><p>%s</p></dd>
        </dl>
        <dl>
            <dt>%s</dt>
            <dd><p>%s</p></dd>
        </dl>
        <dl>
            <dt>Recurs:</dt>
            <dd><p>%s</p></dd>
        </dl>
        <dl>
            <dt>Notes:</dt>
            <dd>%s</dd>
        </dl>
        <dl>
            <dt>Created:</dt>
            <dd><p>%s</p></dd>
        </dl>
    </body>
</html>"""

HTML_BLANK = """
<html>
    <style type="text/css">
        * {background: %s;}
    </style>
    <body>
    </body>
</html>"""

PRIORITY_1 = "The universe depends on it"
PRIORITY_2 = "Absolutely necessary"
PRIORITY_3 = "Very important"
PRIORITY_4 = "Needs to happen"
PRIORITY_5 = "Really should get done"
PRIORITY_6 = "Fairly important"
PRIORITY_7 = "Doesn't matter much"
PRIORITY_8 = "When there's time"
PRIORITY_9 = "Maybe one day"
PRIORITY_10 = "No-one will know the difference"
PRIORITIES = [PRIORITY_1, PRIORITY_2, PRIORITY_3, PRIORITY_4, PRIORITY_5, PRIORITY_6, PRIORITY_7, PRIORITY_8, PRIORITY_9, PRIORITY_10]

DATE_FORMAT_JSON = "%e %b %Y %H:%M:%S"
DATE_FORMAT_DISPLAY = "%e %b %Y"

DEADLINE = "Deadline:"
EVENT = "Occurs On:"

DATE_TYPES = ["No date", DEADLINE, EVENT]

RECURS_NONE = "Never"
RECURS_DAILY = "days"
RECURS_WEEKLY = "weeks"
RECURS_MONTHLY = "months"
RECURS_YEARLY = "years"
RECUR_TYPES = [RECURS_NONE, RECURS_DAILY, RECURS_WEEKLY, RECURS_MONTHLY, RECURS_YEARLY]


# Utility function
def lq_date_string(date, date_format, none_result='n/a'):
    if date == None:
        return none_result
    else:
        return date.strftime(date_format).strip()

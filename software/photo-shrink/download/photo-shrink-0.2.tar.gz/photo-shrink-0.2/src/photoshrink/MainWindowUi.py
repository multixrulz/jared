#  This file is part of photo-resize.
#
#  photo-resize is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  photo-resize is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with TakeStock.  If not, see <http://www.gnu.org/licenses/>.

"""
The photo-resize main window GUI class.
"""

from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5 import uic
import sys
import subprocess
import traceback # For exception handler.
from .QtExtensions import *
from .common import *


class photoshrinkMainWindow(QtWidgets.QMainWindow):
    """The TakeStock main window."""
    def __init__(self, app, *args, **kwargs):
        """
        Create the window.
        """
        self.app = app

        # Set a custom exception hook in order to display a nice message
        # dialog when an exception occurs.
        sys.excepthook = self._custom_exception_hook

        super().__init__(*args, **kwargs)

        # Load the UI
        uic.loadUi(UiFile.MainWindow.filename(), self)

        # Initialisations
        self.lineEdit_dest_dir.setText(os.path.expanduser('~/shrunk/'))
        self.comboBox_filesize.setCurrentText('250kB')
        self.progressBar.hide()

        # Conversions
        psListWidget.morph(self.listWidget_input_files)

        self.show()

    def pb_dest_dir_clicked(self):
        dialog = QtWidgets.QFileDialog()
        dialog.setDirectory(os.path.expanduser('~'))
        dialog.setFileMode(QtWidgets.QFileDialog.DirectoryOnly)
        dialog.setAcceptMode(QtWidgets.QFileDialog.AcceptSave)
        dialog.setOption(QtWidgets.QFileDialog.ShowDirsOnly, True)
        if dialog.exec():
            filenames = dialog.selectedFiles()
            self.lineEdit_dest_dir.setText(filenames[0])

    def pb_shrink_clicked(self):
        # Get the destination directory and ensure it exists.
        dest_dir = self.lineEdit_dest_dir.text()
        if not os.path.exists(dest_dir):
            os.makedirs(dest_dir)
        cmd_array = ['-strip']
        # Get the size and resolution parameters
        filesize = self.comboBox_filesize.currentText()
        resolution = self.comboBox_resolution.currentText()
        res_lookup = {'50kB': '800',
            '100kB': '1200',
            '250kB': '2000',
            '500kB': '3500',
            '1MB': '5000'}
        if resolution == 'Original size':
            pass
        else:
            if resolution == 'Automatic':
                resolution = res_lookup[filesize]
            else:
                resolution = resolution.replace('px', '')
            cmd_array.extend(['-resize', '%sx%s>' % (resolution, resolution)])
        cmd_array.extend(['-define', 'jpeg:extent=%s' % filesize,
            '-define', 'jpeg:optimize-coding=on'])
        # Show a progress bar
        self.progressBar.show()
        self.progressBar.setValue(0)
        # Iterate through the list
        photo_count = self.listWidget_input_files.count()
        for x in range(photo_count):
            # Update the progress bar
            progress = 100*x/photo_count
            self.progressBar.setValue(progress)
            # Do the conversion
            item = self.listWidget_input_files.item(x)
            source = item.data(QtCore.Qt.DisplayRole)
            dest = os.path.join(dest_dir, os.path.basename(source))
            command = ['convert', source] + cmd_array + [dest]
            print(' '.join(command))
            subprocess.call(command)
        # Update the progress bar
        progress = 100
        self.progressBar.setValue(progress)
        self.progressBar.hide()
        # Delete all files from the list
        self.listWidget_input_files.clear()

    def pb_exit_clicked(self):
        self.app.exit()

    def _custom_exception_hook(self, type, value, actual_traceback):
        ### Define a customised sys.excepthook to display exceptions nicely to the user
        traceback_string = "".join(traceback.format_exception(type, value, actual_traceback))
        sys.stderr.write(traceback_string)
        sys.stderr.flush()
        # TODO: TRANSLATE
        primary_text = "Oops! We seem to have hit a bug."
        secondary_text = "Photo-shrink will now close.  The text below will be helpful to the developers."
        exit_app = True

        # Display the error in a message box
        msgbox = QtWidgets.QMessageBox()
        msgbox.setWindowTitle("Photo-shrink Error")
        msgbox.setIcon(QtWidgets.QMessageBox.Critical)
        msgbox.setText("<h1>%s</h1>%s" % (primary_text, secondary_text))
        msgbox.setDetailedText(traceback_string)
        msgbox.setStandardButtons(QtWidgets.QMessageBox.Close)
        msgbox.setDefaultButton(QtWidgets.QMessageBox.Close)
        result = msgbox.exec()
        if exit_app:
            self.app.quit()


if __name__ == '__main__':
    print("You can't run photo-shrink this way.  Try the following instead:\nimport photoresize.app\n\nphotoresize.app.exec()")
